// Export assets here
export { default as Logo } from './OFPPT-Logo.svg?react';
export { default as avatar } from './avatar.png';