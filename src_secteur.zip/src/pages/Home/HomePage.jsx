import QuickActions from './components/QuickActions';
function HomePage() {
  return (
    <div className="flex justify-center flex-wrap gap-4">
      <QuickActions />
    </div>
  );
}

export default HomePage;
