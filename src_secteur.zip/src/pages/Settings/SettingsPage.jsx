const SettingsPage = () => {
  return <div>Settings</div>;
};

export default SettingsPage;
