const TraineesPage = () => {
  return <div>Trainees</div>;
};

export default TraineesPage;
