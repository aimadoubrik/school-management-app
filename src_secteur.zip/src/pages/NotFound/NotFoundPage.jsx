function NotFoundPage() {
  return (
    <div>
      <h1>NotFound Page</h1>
    </div>
  );
}

export default NotFoundPage;
