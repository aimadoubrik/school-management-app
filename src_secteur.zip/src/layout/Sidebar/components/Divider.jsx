const Divider = () => <hr className="h-px bg-base-200 border-0 my-3" aria-hidden="true" />;

export default Divider;
